package utilities;

import java.io.FileInputStream;
import java.util.Properties;

public class PropertyManager {

    private static String url;
    private static String username;
    private static String password;
    private static String invalid_username;
    private static String invalid_password;
    private static String first_name;
    private static String last_name;
    private static String postal_code;

    public static PropertyManager getInstance(){
        Properties properties = new Properties();
        PropertyManager instance = new PropertyManager();

        try {
            FileInputStream fi = new FileInputStream("src/main/resources/configuration.properties");
            properties.load(fi);
        } catch (Exception e) {
            e.printStackTrace();
        }
        url = properties.getProperty("url");
        username = properties.getProperty("username");
        password = properties.getProperty("password");
        invalid_username = properties.getProperty("invalid_username");
        invalid_password = properties.getProperty("invalid_password");
        first_name = properties.getProperty("first_name");
        last_name = properties.getProperty("last_name");
        postal_code = properties.getProperty("postal_code");




        return instance;
    }
    public String getUrl(){
        return url;
    }
    public String getUsername(){
        return username;
    }
    public String getPassword(){
        return password;
    }
    public String getInvalidUsername(){
        return invalid_username;
    }
    public String getInvalidPassword(){
        return invalid_password;
    }
    public String getFirstName(){
        return first_name;
    }
    public String getLastName(){
        return last_name;
    }
    public String getPostalCode(){
        return postal_code;
    }


}
