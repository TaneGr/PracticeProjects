package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class VerificationPage extends BasePage {
        public VerificationPage(WebDriver driver) {
            super(driver);
        }

    By productsTitleBy = By.className("title");
    By loginButtonBy = By.id("login-button");
    By loginErrorBy = By.xpath("//h3[@data-test='error']");
    By purchaseItemBy = By.className("complete-header");
    By addToCartButtonBy = By.id("add-to-cart-sauce-labs-bike-light");


    public VerificationPage verifyLogin(String expectedText) {
        String products = readText(productsTitleBy);
        assertStringEquals(products, expectedText);
        return this;
    }
    public VerificationPage verifyLogout(String expectedText) {
        String loginButtonName = getAttributeText(loginButtonBy, "name");
        assertStringEquals(loginButtonName, expectedText);
        return this;
    }
    public VerificationPage verifyFailedLogin(String expectedText) {
        String error = readText(loginErrorBy);
        assertStringEquals(error, expectedText);
        return this;
    }
    public VerificationPage verifyPurchase(String expectedText) {
        String purchase = readText(purchaseItemBy);
        assertStringEquals(purchase, expectedText);
        return this;
    }
    public VerificationPage verifyEmptyCart(String expectedText) {
        String addToCart = readText(addToCartButtonBy);
        assertStringEquals(addToCart, expectedText);
        return this;
    }

}
