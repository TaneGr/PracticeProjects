package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage extends BasePage {
    public HomePage(WebDriver driver) {super(driver);}

    By menuButtonBy = By.id("react-burger-menu-btn");
    By logoutButtonBy = By.id("logout_sidebar_link");
    By addSauceLabsBikeLightToCartButtonBy = By.id("add-to-cart-sauce-labs-bike-light");
    By shoppingCartButtonBy = By.className("shopping_cart_link");
    By removeSauceLabsBikeLightFromCartBy = By.id("remove-sauce-labs-bike-light");
    By continueButtonBy = By.id("continue-shopping");

    public void logout() {
        click(menuButtonBy);
        click(logoutButtonBy);
    }
    public void addSauceLabsBikeLightToCart(){
        click(addSauceLabsBikeLightToCartButtonBy);
        click(shoppingCartButtonBy);
        click(removeSauceLabsBikeLightFromCartBy);
        click(continueButtonBy);

    }

}
