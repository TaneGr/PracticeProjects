package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CartPage extends BasePage {
    public CartPage(WebDriver driver) {super(driver);}

    By addSauceLabsBikeLightToCartButtonBy = By.id("add-to-cart-sauce-labs-bike-light");
    By shoppingCartButtonBy = By.className("shopping_cart_link");
    By checkoutButtonBy = By.id("checkout");
    By firstNameFieldBy = By.id("first-name");
    By lastNameFieldBy = By.id("last-name");
    By postalcodeFieldBy = By.id("postal-code");
    By continueButtonBy = By.id("continue");
    By finishButtonBy = By.id("finish");
    By completePurchaseBy = By.className("complete-header");


    public void checkout(String first_name, String last_name, String postal_code) {
        click(addSauceLabsBikeLightToCartButtonBy);
        click(shoppingCartButtonBy);
        click(checkoutButtonBy);
        writeText(firstNameFieldBy, first_name);
        writeText(lastNameFieldBy,last_name);
        writeText(postalcodeFieldBy, postal_code);
        click(continueButtonBy);
        click(finishButtonBy);
        click(completePurchaseBy);

    }
}
