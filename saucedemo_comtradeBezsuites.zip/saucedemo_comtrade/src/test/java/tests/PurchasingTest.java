package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.CartPage;
import pages.HomePage;
import pages.VerificationPage;
import utilities.PropertyManager;

public class PurchasingTest extends BaseTestWithLogin{

    //test case 6
    @Test
    public void removeItem(){
        HomePage homePage = new HomePage(driver);
        VerificationPage verificationPage = new VerificationPage(driver);
        homePage.addSauceLabsBikeLightToCart();


        try {
            verificationPage.verifyEmptyCart("ADD TO CART");
            System.out.println("Item is removed, shopping cart is empty.");
        }catch(Exception e){
            Assert.fail("Item is still in the list, something went wrong.");
        }
    }

    //test case 7
    @Test
    public void buyItem(){
       CartPage cartPage = new  CartPage(driver);
        VerificationPage verificationPage = new VerificationPage(driver);
        cartPage.checkout(PropertyManager.getInstance().getFirstName(), PropertyManager.getInstance().getLastName(), PropertyManager.getInstance().getPostalCode());


       try {
            verificationPage.verifyPurchase("THANK YOU FOR YOUR ORDER");
           System.out.println("Item is purchased, thank you for shopping.");
       }catch(Exception e){
            Assert.fail("Item is still in the cart list and not purchased, something went wrong.");
       }
    }

}
