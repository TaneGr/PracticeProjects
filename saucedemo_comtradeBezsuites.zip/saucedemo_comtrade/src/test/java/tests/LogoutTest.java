package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.VerificationPage;


public class LogoutTest extends BaseTestWithLogin{

    //test case 5
    @Test
    public void logout(){
        HomePage homePage = new HomePage(driver);
        VerificationPage verificationPage = new VerificationPage(driver);
        homePage.logout();

        try {
            verificationPage.verifyLogout("login-button");
            System.out.println("User is logged out, login page is shown");
        }catch(Exception e){
            Assert.fail("User is not logged out, something went wrong");
        }
    }
}
