package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.VerificationPage;
import utilities.PropertyManager;

public class LoginTest extends BaseTest{

    //test case 1
    @Test
    public void emptyUsername(){
        VerificationPage verificationPage = new VerificationPage(driver);
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("", PropertyManager.getInstance().getPassword());

        try {
            verificationPage.verifyFailedLogin("Epic sadface: Username is required");
            System.out.println("User is not logged in, username is required");
        }catch (Exception e){
            Assert.fail("Something went wrong");
        }
    }

    //test case 2
    @Test
    public void emptyPassword(){
        VerificationPage verificationPage = new VerificationPage(driver);
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(PropertyManager.getInstance().getUsername(), "");

        try {
            verificationPage.verifyFailedLogin("Epic sadface: Password is required");
            System.out.println("User is not logged in, password is required");
        }catch (Exception e){
            Assert.fail("Something went wrong");
        }
    }

    //test case 3
    @Test
    public void invalidCredentials(){
        VerificationPage verificationPage = new VerificationPage(driver);
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(PropertyManager.getInstance().getInvalidUsername(), PropertyManager.getInstance().getInvalidPassword());

        try {
            verificationPage.verifyFailedLogin("Epic sadface: Username and password do not match any user in this service");
            System.out.println("User is not logged in, invalid credentials");
        }catch (Exception e){
            Assert.fail("Something went wrong");
        }
    }

    //test case 4
    @Test
    public void validLogin(){
        LoginPage loginPage = new LoginPage(driver);
        VerificationPage verificationPage = new VerificationPage(driver);

        loginPage.login(PropertyManager.getInstance().getUsername(), PropertyManager.getInstance().getPassword());

        try {
            verificationPage.verifyLogin("PRODUCTS");
            System.out.print("User is logged in!");
        }catch (Exception e){
            Assert.fail("User is not logged in");
        }
    }
}
