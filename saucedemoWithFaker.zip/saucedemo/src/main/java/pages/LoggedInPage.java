package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoggedInPage extends BasePage{
    public LoggedInPage(WebDriver driver) {
        super(driver);
    }
    By menuButtonBy = By.id("react-burger-menu-btn");
    By logoutButtonBy = By.id("logout_sidebar_link");

    public void logout (){
        click(menuButtonBy);
        click(logoutButtonBy);
    }
}
