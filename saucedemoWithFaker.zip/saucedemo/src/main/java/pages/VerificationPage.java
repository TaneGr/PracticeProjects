package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class VerificationPage extends BasePage {
    public VerificationPage(WebDriver driver) {
        super(driver);
    }

    By productsTitleBy = By.className("title");
    By loginButtonBy = By.id("login-button");
    By loginErrorBy = By.xpath("//h3[@data-test='error']");

    public VerificationPage verifyLogin(String expectedText) {
        String products = readText(productsTitleBy);
        assertStringEquals(products, expectedText);
        return this;
    }
    public VerificationPage verifyLogout(String expectedText) {
        String loginButton = getAttributeText(loginButtonBy, "value");
        assertStringEquals(loginButton, expectedText);
        return this;
    }
    public VerificationPage verifyFailedLogin(String expectedText) {
        String error = readText(loginErrorBy);
        assertStringEquals(error, expectedText);
        return this;
    }
}
