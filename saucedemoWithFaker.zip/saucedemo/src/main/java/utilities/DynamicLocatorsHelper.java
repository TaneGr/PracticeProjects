package utilities;

public class DynamicLocatorsHelper {

    public static String test = "name";
}
