package tests;

import dataCreation.DataCreation;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.VerificationPage;

public class FailedLoginTest extends BaseTest{

    @Test(dataProvider="Failed Login Data")
    public void failedLogin(String username, String password, String errorText){
        VerificationPage verificationPage = new VerificationPage(driver);
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(username, password);

        try {
            verificationPage.verifyFailedLogin(errorText);
            System.out.println("User is not logged in");
        }catch (Exception e){
            Assert.fail("Something went wrong");
        }
    }
    @DataProvider(name = "Failed Login Data")
    public Object [][] getDataFromDataProvider(){
        return new Object[][]
                {
                        {"","","Epic sadface: Username is required"},
                        {DataCreation.fakeUsername(),"","Epic sadface: Password is required"},
                        {"",DataCreation.fakePassword(),"Epic sadface: Username is required"},
                        {DataCreation.fakeUsername(),DataCreation.fakePassword(),"Epic sadface: Username and password do not match any user in this service"}
                };
    }
}
