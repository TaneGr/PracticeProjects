package stepDefinitions;

import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import pages.BasePage;
import pages.DriverUtils;

public class VerificationStepDefinitions extends BasePage {

    public VerificationStepDefinitions(DriverUtils d) {
        super(d.driver);
    }

    @Then("User is logged in")
    public void userIsLoggedIn() {
        String singOut = readText(By.className("logout"));
        assertStringEquals(singOut, "Sign out");
    }
    @Then("Error message is displayed")
    public void errorMessageIsDisplayed() {
        String errorMessage = readText(By.xpath("//*[@id=\"center_column\"]/div[1]"));
        assertStringEquals(errorMessage, "There is 1 error\nAuthentication failed.");
    }
    @Then("User is logged out")
    public void userLoggedOut() {
        String loggedOut = readText(By.id("SubmitLogin"));
        assertStringEquals(loggedOut, "Sign in");
    }
    @Then("Order is completed")
    public void orderCompleted() {
        String orderFinished = readText(By.xpath("//*[@id=\"center_column\"]/div/p/strong"));
        assertStringEquals(orderFinished,"Your order on My Store is complete.");
    }

}
