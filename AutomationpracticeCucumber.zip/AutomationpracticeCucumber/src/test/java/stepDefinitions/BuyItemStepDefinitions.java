package stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import pages.BasePage;
import pages.DriverUtils;

public class BuyItemStepDefinitions extends BasePage {
    public BuyItemStepDefinitions(DriverUtils d) {super((d.driver));}

    @Then("User clicks on T-shirt button")
    public void userClicksOnTShirtButton() {click(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[3]/a"));
    }

    @Then("User clicks on Faded Short Sleeve T-shirts img")
    public void userClicksOnFadedShortSleeveTShirtsImg() {mouseHover(By.xpath("//*[@id=\"center_column\"]/ul/li/div/div[1]/div/a[1]/img"));

    }

    @Then("User clicks on Faded Short Sleeve T-shirts's Add to cart button")
    public void userClicksOnFadedShortSleeveTShirtsSAddToCartButton() {click(By.xpath("//*[@id=\"add_to_cart\"]/button"));
    }
    @And("User waits till pop up for green button is visible to click")
    public void userWaitsTillPopUpForGreenButtonIsVisibleToClick() {waitVisibility(By.xpath("//*[@id=\"layer_cart\"]/div[1]"));
    }

    @Then("User clicks on Proceed to checkout green button")
    public void userClicksOnProceedToCheckoutGreenButton() {clickUsingJavascriptExecutor(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a/span"));
    }

    @Then("User clicks at proceed button at SHOPPING-CART SUMMARY")
    public void userClicksAtProceedButtonAtSHOPPINGCARTSUMMARY() {click(By.xpath("//*[@id=\"center_column\"]/p[2]/a[1]/span"));
    }

    @Then("User clicks at proceed button at ADDRESSES")
    public void userClicksAtProceedButtonAtADDRESSES() {click(By.xpath("//*[@id=\"center_column\"]/form/p/button/span"));
    }

    @Then("User clicks at proceed button at SHIPPING")
    public void userClicksAtProceedButtonAtSHIPPING() {click(By.xpath("//*[@id=\"form\"]/p/button/span"));
    }

    @And("User checks terms and conditions checkbox")
    public void userChecksTermsAndConditionsCheckbox() {click(By.id("uniform-cgv"));
    }

    @Then("User clicks Pay by bank wire at payment method")
    public void userClicksPayByBankWireAtPaymentMethod() {click(By.xpath("//*[@id=\"HOOK_PAYMENT\"]/div[1]/div/p/a"));
    }

    @Then("User clicks at I confirm my order button in ORDER SUMMARY")
    public void userClicksAtIConfirmMyOrderButtonInORDERSUMMARY() {click(By.xpath("//*[@id=\"cart_navigation\"]/button/span"));
    }



}

