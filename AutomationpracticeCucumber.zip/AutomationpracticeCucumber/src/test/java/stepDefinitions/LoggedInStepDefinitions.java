package stepDefinitions;

import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import pages.DriverUtils;
import pages.LoggedInPage;

public class LoggedInStepDefinitions extends LoggedInPage {
    public LoggedInStepDefinitions (DriverUtils d) {super(d.driver);}

    @Then("User clicks on Sign out button")
    public void userClicksOnLogoutButton() {
        click(By.className("logout"));
    }

}

