package pages;

import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class VerificationPage extends BasePage{
    public VerificationPage (WebDriver driver) {
        super(driver);
    }


    By errorNotificationBy =By.xpath("//*[@id=\"center_column\"]/div[1]");
    By signOutButtonBy = By.className("logout");
    By signInButtonBy = By.id("SubmitLogin");
    By completeTextBy = By.xpath("//*[@id=\"center_column\"]/div/p/strong");



    @Then("User is logged in")
    public VerificationPage userIsLoggedIn() {
        String singOut = readText(signOutButtonBy);
        assertStringEquals(singOut, "Sign out");
        return this;
    }
    @Then("Error message is displayed")
    public VerificationPage errorMessageIsDisplayed() {
        String errorMessage = readText(errorNotificationBy);
        assertStringEquals(errorMessage, "There is 1 error\nAuthentication failed.");
        return this;
    }
    @Then("User is logged out")
    public VerificationPage userLoggedOut() {
        String loggedOut = readText(signInButtonBy);
        assertStringEquals(loggedOut, "Sign in");
        return this;
    }
    @Then("Order is completed")
    public VerificationPage orderCompleted() {
        String orderFinished = readText(completeTextBy);
        assertStringEquals(orderFinished,"Your order on My Store is complete.");
        return this;
    }

}

