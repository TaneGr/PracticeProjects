package pages;

import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoggedInPage extends  BasePage{
    public LoggedInPage (WebDriver driver) {
        super(driver);
    }

    By singOutButtonBy = By.className("logout");


    @Then("User clicks on Sign out button")
    public void userClicksOnLogoutButton() {
        click(singOutButtonBy);
    }
}
