package pages;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BuyItemPage extends BasePage{
    public BuyItemPage (WebDriver driver) {
        super(driver);
    }
    By clickOnTButton = By.xpath("//*[@id=\"block_top_menu\"]/ul/li[3]/a");
    By clickOnImg = By.xpath("//*[@id=\"center_column\"]/ul/li/div/div[1]/div/a[1]/img");
    By clickOnTButtonCart = By.xpath("//*[@id=\"add_to_cart\"]/button");
    By waitTillPopup = By.xpath("\"//*[@id=\\\"layer_cart\\\"]/div[1]\"");
    By clickOnProGreen = By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a/span");
    By clickOnProSCS = By.xpath("//*[@id=\"center_column\"]/p[2]/a[1]/span");
    By clickOnADD = By.xpath("//*[@id=\"center_column\"]/form/p/button/span");
    By clickOnShip = By.xpath("//*[@id=\"form\"]/p/button/span");
    By clickOnCheckbox = By.id("uniform-cgv");
    By clickOnPayment = By.xpath("//*[@id=\"HOOK_PAYMENT\"]/div[1]/div/p/a");
    By clickOnConfirm = By.xpath("//*[@id=\"cart_navigation\"]/button/span");



    @Then("User clicks on T-shirt button")
    public void userClicksOnTShirtButton() {click(clickOnTButton);
    }

    @Then("User clicks on Faded Short Sleeve T-shirts img")
    public void userClicksOnFadedShortSleeveTShirtsImg() {mouseHover(clickOnImg);
    }

    @Then("User clicks on Faded Short Sleeve T-shirts's Add to cart button")
    public void userClicksOnFadedShortSleeveTShirtsSAddToCartButton() {click(clickOnTButtonCart);
    }
    @And("User waits till pop up for green button is visible to click")
    public void userWaitsTillPopUpForGreenButtonIsVisibleToClick() {waitVisibility(waitTillPopup);
    }

    @Then("User clicks on Proceed to checkout green button")
    public void userClicksOnProceedToCheckoutGreenButton() {clickUsingJavascriptExecutor(clickOnProGreen);
    }

    @Then("User clicks at proceed button at SHOPPING-CART SUMMARY")
    public void userClicksAtProceedButtonAtSHOPPINGCARTSUMMARY() {click(clickOnProSCS);
    }

    @Then("User clicks at proceed button at ADDRESSES")
    public void userClicksAtProceedButtonAtADDRESSES() {click(clickOnADD);
    }

    @Then("User clicks at proceed button at SHIPPING")
    public void userClicksAtProceedButtonAtSHIPPING() {click(clickOnShip);
    }

    @And("User checks terms and conditions checkbox")
    public void userChecksTermsAndConditionsCheckbox() {click(clickOnCheckbox);
    }

    @Then("User clicks Pay by bank wire at payment method")
    public void userClicksPayByBankWireAtPaymentMethod() {click(clickOnPayment);
    }

    @Then("User clicks at I confirm my order button in ORDER SUMMARY")
    public void userClicksAtIConfirmMyOrderButtonInORDERSUMMARY() {click(clickOnConfirm);
    }


}
