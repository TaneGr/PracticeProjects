package pages;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage extends BasePage{
    public LoginPage (WebDriver driver) {
        super(driver);
    }

    By signInButtonBy = By.className("login");
    By emailTextFieldBy = By.id("email");
    By passwordTextFieldBy = By.id("passwd");
    By loginButtonBy = By.id("SubmitLogin");


    @Given("Navigate to Sign in page")
    public void navigateToSignInPage(){ click(signInButtonBy);
    }
    @When("User enters {string} in email field")
    public void userEntersInEmailField(String email) {writeText(emailTextFieldBy, email);
    }
    @And("User enters {string} in password field")
    public void userEntersInPasswordField(String password) {writeText(passwordTextFieldBy, password);
    }
    @And("User clicks on Sign in button")
    public void userClicksOnSignInButton() {click(loginButtonBy);
    }

}
