package tests;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class BaseClass {

        AndroidDriver<AndroidElement> driver;

    public BaseClass(AndroidDriver<AndroidElement> driver) {
            this.driver = driver;
        }
}
