package tests;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import java.net.MalformedURLException;
import java.net.URL;

public class YouTube extends BaseClass {

    AndroidDriver driver;
    DesiredCapabilities capabilities;

    public YouTube(AndroidDriver<AndroidElement> driver) {
        super(driver);
    }

    @BeforeClass
    public void setUp() throws MalformedURLException {
        capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,"emulator-5554");
        capabilities.setCapability("platformName","Android");

        capabilities.setCapability("appPackage","com.google.android.youtube");
        capabilities.setCapability("appActivity","com.google.android.youtube.HomeActivity");
        driver = new AndroidDriver<AndroidElement>( new URL("https://127.0.0.1:4723/wd/hub"), capabilities);

    }

    @Test
    public void testYou() throws Exception {

        AndroidDriver<AndroidElement> driver;
        driver = new AndroidDriver<AndroidElement>( new URL("https://127.0.0.1:4723/wd/hub"), capabilities);

        MobileElement search = (MobileElement)  driver.findElementByXPath("//android.widget.ImageView[@content-desc=\"Search\"]");
        search.click();
        MobileElement  searchInput = (MobileElement)  driver.findElementById("com.google.android.youtube:id/search_edit_text");
        searchInput.click();
        searchInput.sendKeys("Partizan Beograd");
        MobileElement firstSearchResult = (MobileElement) driver.findElementByXPath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.view.ViewGroup/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[1]/android.widget.ImageView[1]\n");
        firstSearchResult.click();
        MobileElement options = (MobileElement) driver.findElementByXPath("//android.widget.ImageView[@content-desc=\"Action menu\"]\n");
        options.click();
        MobileElement saveToPlaylist = (MobileElement) driver.findElementByXPath("//android.widget.LinearLayout[@content-desc=\"Save to playlist\"]/android.widget.TextView\n");
        saveToPlaylist.click();
        MobileElement createPlaylist = (MobileElement) driver.findElementById("com.google.android.youtube:id/button\n");
        createPlaylist.click();
        MobileElement playlistTitle = (MobileElement) driver.findElementById("com.google.android.youtube:id/name\n");
        playlistTitle.sendKeys("PartizanSampion");
        MobileElement create = (MobileElement) driver.findElementById("com.google.android.youtube:id/create_button\n");
        create.click();



     }
}
